#!/bin/sh
rst2html README.rst > README.html && xdg-open README.html
